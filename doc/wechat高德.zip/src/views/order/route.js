const _import = require('@/router/_import_' + process.env.NODE_ENV)
//模块路由
export default [
    // { name: 'order', path: '/order', component: _import('order/index'), meta: { verifylogin: true } },
]
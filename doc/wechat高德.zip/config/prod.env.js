'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"https://mobile.xmxtm.cn/api/API/"',
  WECHAT_API: '"https://mobile.xmxtm.cn/API/"',
  // BASE_API: '"http://localhost:59358/api/"',
  IMG_URL: '""',
}
